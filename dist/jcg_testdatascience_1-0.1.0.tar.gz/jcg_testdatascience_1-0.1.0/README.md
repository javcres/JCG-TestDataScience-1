# Ejercicio 1 Prueba Capgemini

> Propuesta de solución para el ejercicio de clasificación, incluyendo el análisis exploratorio, el procesado de datos y selección del modelo y la puesta en producción del mismo.

## Tabla de contenidos

TODO..

## Documentación del proyecto



## Organización del respositorio

TODO referenciar a los pibes del curso


## Ejecutar el código proporcionado

